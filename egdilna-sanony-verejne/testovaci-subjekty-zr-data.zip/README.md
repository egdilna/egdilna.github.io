# Testovací subjekty základních registrů — datový export do JSON

Balíček obsahuje `data.json` (data), `schema.json` (JSON Schema popisující právě tento výstup), `mapovani.json` (převod interních ID na klíče) a tento popis. Schéma bylo ověřeno proti přiloženým datům.

- Exportováno: 2. 9. 2026 9:20:15
- Počet entit: 469
- Styl klíčů: snake
- Jak zapsat vazby: Odkaz — { ref, typ, nazev }
- Kontrola dat proti schématu: Data odpovídají schématu.

## `doklad` — Doklad (36)

| Klíč | Název | Typ atributu | Zdroj |
|---|---|---|---|
| `cislo_dokladu` | Číslo dokladu | Text (jeden řádek) | Doklad |
| `druh_dokladu` | Druh dokladu | Výběr ze seznamu | Doklad |
| `platnost_do` | Platnost do | Text (jeden řádek) | Doklad |
| `drzitel` | Držitel | Relace na entitu | Doklad |

## `fyzicka_osoba` — Fyzická osoba (52)

| Klíč | Název | Typ atributu | Zdroj |
|---|---|---|---|
| `prijmeni` | Příjmení | Text (jeden řádek) | Fyzická osoba |
| `jmeno` | Jméno | Text (jeden řádek) | Fyzická osoba |
| `rodne_prijmeni` | Rodné příjmení | Text (jeden řádek) | Fyzická osoba |
| `pohlavi` | Pohlaví | Výběr ze seznamu | Fyzická osoba |
| `datum_narozeni` | Datum narození | Datum | Fyzická osoba |
| `misto_narozeni_kod_ruian` | Místo narození (kód RUIAN) | Text (jeden řádek) | Fyzická osoba |
| `misto_narozeni_ve_svete` | Místo narození ve světě | Text (jeden řádek) | Fyzická osoba |
| `stat_narozeni` | Stát narození | Relace na entitu | Fyzická osoba |
| `datum_umrti` | Datum úmrtí | Datum | Fyzická osoba |
| `datum_pravni_moci_umrti` | Datum právní moci úmrtí | Datum | Fyzická osoba |
| `misto_umrti_kod_ruian` | Místo úmrtí (kód RUIAN) | Text (jeden řádek) | Fyzická osoba |
| `adresa_pobytu_kod_ruian` | Adresa pobytu (kód RUIAN) | Text (jeden řádek) | Fyzická osoba |
| `dorucovaci_adresa_kod_ruian` | Doručovací adresa (kód RUIAN) | Text (jeden řádek) | Fyzická osoba |
| `datova_schranka_identifikator` | Datová schránka (identifikátor) | Text (jeden řádek) | Fyzická osoba |
| `obcanstvi` | Občanství | Relace na entitu | Fyzická osoba |
| `omezeni_svepravnosti` | Omezení svéprávnosti | Ano/Ne | Fyzická osoba |
| `rodinny_stav_partnerstvi` | Rodinný stav / partnerství | Výběr ze seznamu | Fyzická osoba |
| `fixni_testovaci_identita` | Fixní testovací identita | Ano/Ne | Fyzická osoba |

## `informace` — Informace (2)

| Klíč | Název | Typ atributu | Zdroj |
|---|---|---|---|
| `obsah_2` | Obsah | Text (víceřádkový, Markdown + CriticMarkup) | Informace |

## `pravnicka_osoba` — Právnická osoba (99)

| Klíč | Název | Typ atributu | Zdroj |
|---|---|---|---|
| `ico` | IČO | Text (jeden řádek) | Právnická osoba |
| `nazev_2` | Název | Text (jeden řádek) | Právnická osoba |
| `typ_osoby` | Typ osoby | Výběr ze seznamu | Právnická osoba |
| `pravni_forma` | Právní forma | Výběr ze seznamu | Právnická osoba |
| `datum_vzniku` | Datum vzniku | Datum | Právnická osoba |
| `datum_zaniku` | Datum zániku | Datum | Právnická osoba |
| `kod_agendy_registrace` | Kód agendy (registrace) | Text (jeden řádek) | Právnická osoba |
| `kod_ovm_registrace` | Kód OVM (registrace) | Text (jeden řádek) | Právnická osoba |
| `preruseni_pozastaveni_cinnosti` | Přerušení / pozastavení činnosti | Text (jeden řádek) | Právnická osoba |
| `adresa_sidla_kod_ruian` | Adresa sídla (kód RUIAN) | Text (jeden řádek) | Právnická osoba |
| `dorucovaci_adresa` | Doručovací adresa | Text (jeden řádek) | Právnická osoba |
| `kontaktni_telefon` | Kontaktní telefon | Text (jeden řádek) | Právnická osoba |
| `kontaktni_email` | Kontaktní email | Text (jeden řádek) | Právnická osoba |
| `datova_schranka_identifikator` | Datová schránka (identifikátor) | Text (jeden řádek) | Právnická osoba |
| `typ_datove_schranky` | Typ datové schránky | Výběr ze seznamu | Právnická osoba |
| `podnikatel_u_pfo` | Podnikatel (u PFO) | Relace na entitu | Právnická osoba |
| `statutarni_zastupce` | Statutární zástupce | Relace na entitu | Právnická osoba |
| `provozovny_kody` | Provozovny (kódy) | Text (jeden řádek) | Právnická osoba |
| `fixni_testovaci_identita` | Fixní testovací identita | Ano/Ne | Právnická osoba |

Vazby: `ma_jednatele` (Má jednatele), `ma_podnikatele` (Má podnikatele)

## `stat` — Stát (280)

| Klíč | Název | Typ atributu | Zdroj |
|---|---|---|---|
| `numericky_kod` | Numerický kód | Text (jeden řádek) | Stát |
| `dvouznakovy_kod` | Dvouznakový kód | Text (jeden řádek) | Stát |
| `triznakovy_kod` | Tříznakový kód | Text (jeden řádek) | Stát |
| `nazev_statu` | Název státu | Text (jeden řádek) | Stát |
| `zkraceny_nazev` | Zkrácený název | Text (jeden řádek) | Stát |
| `anglicky_nazev` | Anglický název | Text (jeden řádek) | Stát |
| `platnost_od` | Platnost od | Text (jeden řádek) | Stát |
| `platnost_do` | Platnost do | Text (jeden řádek) | Stát |

## Upozornění

- Klíč „obsah“ se v typu Informace opakuje, použit „obsah_2“.
- Klíč „nazev“ se v typu Právnická osoba opakuje, použit „nazev_2“.
